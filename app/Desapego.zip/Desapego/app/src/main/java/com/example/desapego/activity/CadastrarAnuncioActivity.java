package com.example.desapego.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.style.MaskFilterSpan;
import android.view.View;
import android.widget.EditText;

import com.example.desapego.R;
import com.santalu.maskedittext.MaskEditText;

public class CadastrarAnuncioActivity extends AppCompatActivity {

    private EditText campoTitulo, campoDescricao;
    private MaskEditText campoTelefone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_anuncio);

        inicializarComponentes();
    }

    private void inicializarComponentes(){
        campoTitulo = findViewById(R.id.editTitulo);
        campoDescricao = findViewById(R.id.editDescricao);
        campoTelefone =findViewById(R.id.editTelefone);
    }

    public void salvarAnuncio(View view) {

    }

}
